const terrain_check = document.getElementById('terrain_check');
const roads_check = document.getElementById('roads_check');
const cities_check = document.getElementById('cities_check');
const villages_check = document.getElementById('villages_check');

const rivers_check = document.getElementById('rivers_check');
const mountains_check = document.getElementById('mountains_check');
const forests_check = document.getElementById('forests_check');

terrain_check.checked = true;
rivers_check.checked = true;
mountains_check.checked = true;
forests_check.checked = true;
roads_check.checked = true;
cities_check.checked = true;
villages_check.checked = true;

const terrain_layer = document.getElementById('terrain');
const roads_layer = document.getElementById('roads');
const cities_layer = document.getElementById('cities');
const villages_layer = document.getElementById('villages');

const rivers_layer = document.getElementById('rivers');
const mountains_layer = document.getElementById('mountains');
const forests_layer = document.getElementById('forests');


terrain_check.addEventListener('change', () => {
    if (terrain_layer.style.display === "none") {
        terrain_layer.style.display = "block";
    } else {
        terrain_layer.style.display = "none";
    }
});

rivers_check.addEventListener('change', () => {
    if (rivers_layer.style.display === "none") {
        rivers_layer.style.display = "block";
    } else {
        rivers_layer.style.display = "none";
    }
});

mountains_check.addEventListener('change', () => {
    if (mountains_layer.style.display === "none") {
        mountains_layer.style.display = "block";
    } else {
        mountains_layer.style.display = "none";
    }
});

forests_check.addEventListener('change', () => {
    if (forests_layer.style.display === "none") {
        forests_layer.style.display = "block";
    } else {
        forests_layer.style.display = "none";
    }
});

roads_check.addEventListener('change', () => {
    if (roads_layer.style.display === "none") {
        roads_layer.style.display = "block";
    } else {
        roads_layer.style.display = "none";
    }
});

cities_check.addEventListener('change', () => {
    if (cities_layer.style.display === "none") {
        cities_layer.style.display = "block";
    } else {
        cities_layer.style.display = "none";
    }
});

villages_check.addEventListener('change', () => {
    if (villages_layer.style.display === "none") {
        villages_layer.style.display = "block";
    } else {
        villages_layer.style.display = "none";
    }
});